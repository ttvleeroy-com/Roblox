import dotenv from 'dotenv';
import { Client, GatewayIntentBits } from 'discord.js';
import fs from 'fs';
import path from 'path';

// Import the command handler
import commandHandler from './commands/commandHandler.js';

// Initialize the bot client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

// Event handler for when the bot is ready
client.once('ready', () => {
  console.log('Bot is ready!');
});

// Event handler for messages
client.on('messageCreate', async (message) => {
  if (message.author.bot) return; // Ignore messages from other bots

  // Command handling
  if (message.content.startsWith('!')) {
    const args = message.content.slice(1).split(' ');
    const commandName = args.shift().toLowerCase();

    try {
      // Execute the corresponding command
      await commandHandler(client, commandName, args, message);
    } catch (error) {
      console.error(error);
      message.channel.send('An error occurred while processing your command.');
    }
  }

  // Handling /say command
  if (message.content.startsWith('/say') && message.author.id === '952345632696336385') {
    const sayMessage = message.content.slice(5);  // Remove '/say ' from the start
    if (!sayMessage) {
      return message.channel.send('Please provide a message for me to say.');
    }
    const channel = message.channel;
    await channel.send(sayMessage); // Bot sends the message to the same channel
  }
});

dotenv.config();
client.login(process.env.BOT_TOKEN);
