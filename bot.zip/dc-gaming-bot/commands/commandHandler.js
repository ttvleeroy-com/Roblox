// Importing commands
import gambleCommand from './gamble.js';  // Assuming gamble.js is in the same directory
import helpCommand from './help.js';
import evalCommand from './eval.js';
import sayCommand from './say.js';  // Importing the say command

const commandHandler = async (client, commandName, args, message) => {
  switch (commandName) {
    case 'gamble':
      // Pass userBalances only if needed in the gamble command
      await gambleCommand(client, args, message);
      break;
    case 'help':
      await helpCommand(message);
      break;
    case 'eval':
      await evalCommand(message, args); // Handle the eval command
      break;
    case 'say':
      await sayCommand(client, args, message); // Handle the say command
      break;
    default:
      message.channel.send('Unknown command. Type !help for a list of commands.');
  }
};

export default commandHandler;
