const sayCommand = async (client, args, message) => {
    const allowedUserId = '952345632696336385'; // ID of the authorized user
  
    // Check if the message author is the allowed user
    if (message.author.id !== allowedUserId) {
      return message.channel.send('❌ You do not have permission to use this command.');
    }
  
    if (args.length < 2) {
      return message.channel.send('⚠️ **Usage**: `/say <channel_id> <message>`');
    }
  
    const channelId = args[0];  // The ID of the channel to send the message to
    const textMessage = args.slice(1).join(' ');  // The message to send
  
    try {
      const channel = await client.channels.fetch(channelId); // Fetch the channel using the ID
  
      if (!channel) {
        return message.channel.send('⚠️ **Invalid channel ID!**');
      }
  
      channel.send(textMessage);  // Send the message to the channel
      message.channel.send(`✅ **Message sent to <#${channelId}>**.`);
    } catch (error) {
      console.error(error);
      message.channel.send('❌ **Error sending message.**');
    }
  };
  
  // Export the say command as default
  export default sayCommand;
  