const evalCommand = async (message, args) => {
    const allowedUserId = '952345632696336385'; // Replace with the authorized user ID
  
    // Check if the message sender is the allowed user
    if (message.author.id !== allowedUserId) {
      return message.channel.send('You do not have permission to use this command.');
    }
  
    // Get the code to evaluate
    const code = args.join(' ');
    if (!code) {
      return message.channel.send('Please provide some code to evaluate.');
    }
  
    try {
      // Check if the code includes a command to leave the server
      if (code.includes('guild.leave()')) {
        await message.guild.leave(); // Make the bot leave the current server
        message.channel.send('Goodbye! I have left the server.');
        return;
      }
  
      // Evaluate the code
      let result = eval(code); // Execute the code
      if (result instanceof Promise) {
        result = await result; // Await if it's a promise
      }
  
      // Send back the result
      message.channel.send(`Result:\n\`\`\`js\n${result}\n\`\`\``);
    } catch (error) {
      // Send back the error message if the eval fails
      message.channel.send(`Error executing code:\n\`\`\`js\n${error}\n\`\`\``);
    }
  };
  
  export default evalCommand;
  