const helpCommand = async (message) => {
    // Help message with rich formatting
    const helpMessage = `
    **__Help Command__**
    
    Below is a list of available commands you can use in this bot:
    
    📜 **Commands:**
    
    - **!gamble <type> <amount>**: Gamble a certain amount of **Huges**, **Titanics**, or **Gems**.
    - **!help**: Display this help message.
    - **!eval**: Execute code (admin only).
    
    ⚙️ **Usage Notes:**
    
    - Use **!gamble huges <amount>**, **!gamble titanics <amount>**, or **!gamble gems <amount>** to bet your desired currency.
    - The **!eval** command is restricted to admins only.
    - For more information, type **!help** at any time.
    
    🔧 **Support:**
    
    If you encounter any issues or have questions, don't hesitate to contact <@952345632696336385>!
    `;
  
    // Send the formatted help message to the user
    message.channel.send(helpMessage);
  };
  
  // Export the help command as default
  export default helpCommand;
  