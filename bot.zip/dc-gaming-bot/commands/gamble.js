const gambleCommand = async (client, args, message) => {
    if (args.length < 2) {
      return message.channel.send('⚠️ **Usage**: `!gamble <type> <amount>`');
    }
  
    const type = args[0].toLowerCase();
    const amount = parseInt(args[1]);
  
    if (isNaN(amount) || amount <= 0) {
      return message.channel.send('⚠️ **Invalid amount!** Please enter a valid amount to gamble.');
    }
  
    // Simulate gambling with complex odds and multiple outcomes
    const { message: outcomeMessage, change } = gambleOutcome(type, amount);
  
    // Send the outcome message to the user
    message.channel.send(outcomeMessage);
  
    // Optionally, handle the change value here (e.g., adjusting a user's balance)
  };
  
  function gambleOutcome(type, amount) {
    let message;
    let change = 0;
    const hugesWinChance = 0.3; // 30% win chance for Huges
    const titanicsWinChance = 0.01; // 1% win chance for Titanics
    const gemsWinChance = 0.3; // 30% win chance for Gems
  
    switch (type) {
      case 'huges':
        if (Math.random() < hugesWinChance) {
          change = amount * 1; // Win 1x the bet
          message = `🎉 **You won ${change} Huges!**`;
        } else {
          change = -amount;
          message = `💔 **You lost ${amount} Huges.**`;
        }
        break;
  
      case 'titanics':
        if (Math.random() < titanicsWinChance) {
          change = amount * 2; // Win 2x the bet
          message = `🎉 **You won ${change} Titanics!**`;
        } else {
          change = -amount;
          message = `💔 **You lost ${amount} Titanics.**`;
        }
        break;
  
      case 'gems':
        if (Math.random() < gemsWinChance) {
          change = amount * 2.5; // Win 2.5x the bet
          message = `🎉 **You won ${change} Gems!**`;
        } else {
          change = -amount;
          message = `💔 **You lost ${amount} Gems.**`;
        }
        break;
  
      default:
        message = '⚠️ **Invalid gambling type!** Please choose between "huges", "titanics", or "gems".';
        break;
    }
  
    return { message, change };
  }
  
  // Export the gamble command as default
  export default gambleCommand;
  